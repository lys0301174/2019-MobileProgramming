package com.example.testlayout;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class LoginActivity extends AppCompatActivity {
    private EditText etID;
    private EditText etPW;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setTitle("로그인 화면");

        etID = (EditText) findViewById(R.id.EditTextID);
        etPW = (EditText) findViewById(R.id.EditTextPW);

        Button SignUpButton = (Button) findViewById(R.id.SignUpButton);
        final Button LogInButton = (Button) findViewById(R.id.LogInButton);

        //로그인 버튼 클릭
        LogInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etID.getText().toString().length() == 0 && etPW.getText().toString().length() == 0) {
                    Toast.makeText(LoginActivity.this, "아이디와 비밀번호를 입력하세요", Toast.LENGTH_SHORT).show();
                    etID.requestFocus();
                    return;
                }
                else if (etID.getText().toString().length() == 0) {
                    Toast.makeText(LoginActivity.this, "아이디를 입력하세요", Toast.LENGTH_SHORT).show();
                    etID.requestFocus();
                    return;
                }
                else if (etPW.getText().toString().length() == 0) {
                    Toast.makeText(LoginActivity.this, "비밀번호를 입력하세요", Toast.LENGTH_SHORT).show();
                    etPW.requestFocus();
                    return;
                }
                else if (userCheck()) {
                    Intent intent_login = new Intent(getApplicationContext(),
                            LookupActivity.class);
                    startActivity(intent_login);
                    Toast.makeText(LoginActivity.this, "로그인에 성공했습니다", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(LoginActivity.this, "아이디 혹은 비밀번호를 다시 확인하세요", Toast.LENGTH_SHORT).show();

            }
        });


        //회원가입 버튼 클릭
        SignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),
                        SignupActivity.class);
                startActivity(intent);
            }
        });

    }

    private Boolean userCheck() {
        int finalAccept = 0;
        List<Object> userID = new ArrayList<Object>();
        List<Object> userPW = new ArrayList<Object>();
        String inputID = etID.getText().toString();
        String inputPW = etPW.getText().toString();

        userID.add("lys0301");
        userID.add("lsk0920");
        userID.add("hjs1211");
        userID.add("kung0301");
        userID.add("asdf1234");

        userPW.add("Unknown01!");
        userPW.add("unknown&02");
        userPW.add("Unknown03");
        userPW.add("unknown");
        userPW.add("unknownunknown");

        for (int i = 0; i < userID.size(); i++) {
            if (userID.get(i).equals(inputID)) {
                finalAccept++;
                break;
            }
            else
                finalAccept = 0;
        }

        for (int i = 0; i < userPW.size(); i++) {
            if (userPW.get(i).equals(inputPW)) {
                finalAccept++;
                break;
            }
            else
                finalAccept += 0;
        }

        if (finalAccept == 2)
            return true;
        else
            return false;
    }

}
