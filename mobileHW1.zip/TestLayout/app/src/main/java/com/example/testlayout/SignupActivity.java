package com.example.testlayout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

//중복 아니고 조건 맞춰서 작성한 회원이 가입 버튼 누르면 해당 정보 저장한 텍스트파일 생성해서 유저 정보 저장?

public class SignupActivity extends Activity {
    private TextView tvWarnID;
    private TextView tvWarnPW;
    private EditText etID;
    private EditText etPassword;
    private EditText etPasswordConfirm;
    private EditText etName;
    private EditText etPhonenum;
    private EditText etAddress;
    private RadioButton radDisagree;
    private Button signupBtn;


    @Override
    protected  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        setTitle("회원가입 액티비티");

        //개인정보 이용약관 출력
        TextView ToS = (TextView)findViewById(R.id.ToStext);
        ToS.setText(readText());

        ToS.setMovementMethod(new ScrollingMovementMethod());

        final ScrollView sv;
        sv = (ScrollView)findViewById(R.id.sv1);

        ToS.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                sv.requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        tvWarnID = (TextView)findViewById(R.id.warnID);
        tvWarnPW = (TextView)findViewById(R.id.warnPW);
        etID = (EditText)findViewById(R.id.SignUpID_ET);
        etPassword = (EditText)findViewById(R.id.SignUpPW_ET);
        etPasswordConfirm = (EditText)findViewById(R.id.SignUpRPW_ET);
        etName = (EditText)findViewById(R.id.SignUpName_ET);
        etPhonenum = (EditText)findViewById(R.id.SignUpPhoneNum_ET);
        etAddress = (EditText)findViewById(R.id.SignUpAddress_ET);
        radDisagree = (RadioButton)findViewById(R.id.Disagree);
        signupBtn = (Button)findViewById(R.id.SignUpSaveBtn);

        //ID 중복검사
        etID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!userCheck()) {
                    tvWarnID.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (etID.getText().toString().length() == 0)
                    tvWarnID.setVisibility(View.INVISIBLE);
            }
        });


        //비밀번호 일치검사
        etPasswordConfirm.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!etPassword.getText().toString().equals(etPasswordConfirm.getText().toString())) {
                    tvWarnPW.setVisibility(View.VISIBLE);
                    //Toast.makeText(SignupActivity.this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                    //etPassword.setText("");
                    //etPasswordConfirm.setText("");
                    //etPassword.requestFocus();
                }
                else if (etPassword.getText().toString().equals(etPasswordConfirm.getText().toString()))
                    tvWarnPW.setVisibility(View.INVISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });


        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ID 입력 확인
                if (etID.getText().toString().length() == 0) {
                    Toast.makeText(SignupActivity.this, "아이디를 입력하세요", Toast.LENGTH_SHORT).show();
                    etID.requestFocus();
                    return;
                }

                //비밀번호 입력 확인
                if (etPassword.getText().toString().length() == 0) {
                    Toast.makeText(SignupActivity.this, "비밀번호를 입력하세요", Toast.LENGTH_SHORT).show();
                    etPassword.requestFocus();
                    return;
                }

                //비밀번호 길이 확인(8이상 12이하)
                if (etPassword.getText().toString().length() < 8 && etPassword.getText().toString().length() > 12) {
                    Toast.makeText(SignupActivity.this, "비밀번호 길이를 확인해주세요", Toast.LENGTH_SHORT).show();
                    etPassword.setText("");
                    return;
                }

                //비밀번호 재확인 입력 확인
                if (etPasswordConfirm.getText().toString().length() == 0) {
                    Toast.makeText(SignupActivity.this, "비밀번호 재확인을 입력하세요", Toast.LENGTH_SHORT).show();
                    etPasswordConfirm.requestFocus();
                    return;
                }

                //비밀번호-비밀번호 재확인 일치 확인
                if (!etPassword.getText().toString().equals(etPasswordConfirm.getText().toString())) {
                    tvWarnPW.setVisibility(View.VISIBLE);
                    Toast.makeText(SignupActivity.this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                    etPassword.setText("");
                    etPasswordConfirm.setText("");
                    etPassword.requestFocus();
                    return;
                }

                //이름 입력 확인
                if (etName.getText().toString().length() == 0) {
                    Toast.makeText(SignupActivity.this, "이름을 입력하세요", Toast.LENGTH_SHORT).show();
                    return;
                }

                //휴대전화 입력 확인
                if (etPhonenum.getText().toString().length() == 0) {
                    Toast.makeText(SignupActivity.this, "휴대전화번호를 입력하세요", Toast.LENGTH_SHORT).show();
                    return;
                }

                //주소 입력 확인
                if (etAddress.getText().toString().length() == 0) {
                    Toast.makeText(SignupActivity.this, "주소를 입력하세요", Toast.LENGTH_SHORT).show();
                    return;
                }

                //개인정보 동의에 체크했는지 확인
                if (radDisagree.isChecked()) {
                    Toast.makeText(SignupActivity.this, "개인정보 이용동의서에 동의 해주세요", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (savedUserData()) {
                    Intent intent = new Intent(getApplicationContext(),
                            LoginActivity.class);
                    startActivity(intent);
                }

                finish();
            }
        });

    }

    private String readText() {
        String data = null;
        InputStream inputStream = getResources().openRawResource(R.raw.tos);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        int i;
        try {
            i = inputStream.read();
            while(i != -1) {
                byteArrayOutputStream.write(i);
                i = inputStream.read();
            }

            data = new String(byteArrayOutputStream.toByteArray(), "UTF-8");
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    private Boolean userCheck() {
        int accept = 0;
        List<Object> userID = new ArrayList<Object>();
        String inputID = etID.getText().toString();

        userID.add("lys0301");
        userID.add("lsk0920");
        userID.add("hjs1211");
        userID.add("kung0301");
        userID.add("asdf1234");


        for (int i = 0; i < userID.size(); i++) {
            if (userID.get(i).equals(inputID)) {
                accept++;
                break;
            }
            else
                accept = 0;
        }

        if (accept == 0)
            return true;
        else
            return false;
    }

    private Boolean savedUserData() {
        List<Object> userData = new ArrayList<Object>();

        userData.add(etID.getText().toString());
        userData.add(etPassword.getText().toString());
        userData.add(etName.getText().toString());
        userData.add(etPhonenum.getText().toString());
        userData.add(etAddress.getText().toString());

        return true;
    }

}
