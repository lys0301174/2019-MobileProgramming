package com.example.testlayout;

import android.app.Activity;
import android.os.Bundle;
import android.widget.RadioButton;

public class LookupActivity extends Activity {
    private RadioButton domestic;

    @Override
    protected  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lookup);
        setTitle("메인기능 액티비티");

        domestic = (RadioButton) findViewById(R.id.domesticBook);
        domestic.setChecked(true);

    }
}
